	<tr class="section">
		<th colspan="2"><?php echo $content; ?></th>
	</tr>
