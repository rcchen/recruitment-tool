
</div>
<!-- End Page Content -->

<!-- Footer -->

<div class="legal">
	<div class="copyright">
		<div class="license"><a rel="license" href="http://creativecommons.org/licenses/by-sa/3.0/us/"><img alt="Creative Commons License" style="border-width:0" src="<?php echo str_replace('index.php/','',site_url('img/cc.png')); ?>" /></a></div>
		<div class="licenseInfo">Squash Bug Tracker App &copy;2009-<?php echo date('Y'); ?> <a href="http://datamapper.wanwizard.eu/">DataMapper Development Team</a></div>
	</div>
	<div class="resources">
		<strong>This site is intended for education of <a href="http://datamapper.wanwizard.eu/">DataMapper ORM</a> purposes only.</strong><br/>
		The design includes content from: <a href="http://www.everaldo.com/crystal/">Everaldo.com</a>, <a href="http://www.sxc.hu/photo/1199868">stock.xchng / lauralucia</a>.<br/>
		Please do not redistribute the example website or it's design, unless it is part of a DataMapper download.
	</div>
</div>

<!-- End Footer -->

</body>
</html>
