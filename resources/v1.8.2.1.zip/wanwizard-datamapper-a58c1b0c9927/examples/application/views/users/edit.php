<?php

	echo $user->render_form($form_fields, $url);

?>