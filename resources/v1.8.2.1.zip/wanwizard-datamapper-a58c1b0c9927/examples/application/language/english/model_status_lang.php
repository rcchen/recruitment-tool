<?php

$lang['status_name']				= 'Name';
$lang['status_closed']				= 'Status Means Bug is Closed?';
$lang['status_unset']				= '«Unset Status»';

/* End of file model_status_lang.php */
/* Location: ./application/language/english/model_status_lang.php */