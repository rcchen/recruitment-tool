<?php

$lang['comment_comment']		= 'Comment';
$lang['comment_bug']			= 'Bug';
$lang['comment_user']			= 'User';

/* End of file model_comment_lang.php */
/* Location: ./application/language/english/model_comment_lang.php */