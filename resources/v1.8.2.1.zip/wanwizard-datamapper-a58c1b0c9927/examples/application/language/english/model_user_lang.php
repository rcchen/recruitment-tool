<?php

$lang['user_name']				= 'Name';
$lang['user_email']				= 'Email';
$lang['user_username']			= 'Username';
$lang['user_password']			= 'Password';
$lang['user_confirm_password']	= 'Confirm Password';

// Realtionships
$lang['user_group']				= 'Group';
$lang['user_created_bug']		= 'Bugs Created by this User';
$lang['user_edited_bug']		= 'Bugs Edited by this User';

// Other
$lang['user_newuser']			= '«New User»';

// Errors
$lang['user_error_login']		= 'Username or password invalid';

/* End of file model_user_lang.php */
/* Location: ./application/language/english/model_user_lang.php */