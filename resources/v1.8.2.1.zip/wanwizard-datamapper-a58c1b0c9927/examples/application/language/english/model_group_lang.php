<?php

$lang['group_name']				= 'Name';
$lang['group_unset']			= '«Unset Group»';

/* End of file model_group_lang.php */
/* Location: ./application/language/english/model_group_lang.php */