<?php

$lang['bug_title']			= 'Title';
$lang['bug_description']	= 'Description';
$lang['bug_priority']		= 'Priority';
$lang['bug_creator']		= 'Creator';
$lang['bug_editor']			= 'Editor';
$lang['bug_status']			= 'Status';
$lang['bug_category']		= 'Categories';
$lang['bug_user']			= 'Assigned Users';
$lang['bug_dependency']		= 'This bug depends on';
$lang['bug_dependents']		= 'Other bugs that depend on this';

/* End of file model_bug_lang.php */
/* Location: ./application/language/english/model_bug_lang.php */