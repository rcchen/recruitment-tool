<?php

$lang['category_name']		= 'Name';

$lang['category_unset']		= '«Unset Category»';

/* End of file model_category_lang.php */
/* Location: ./application/language/english/model_category_lang.php */